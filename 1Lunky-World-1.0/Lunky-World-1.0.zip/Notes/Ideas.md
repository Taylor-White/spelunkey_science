# Levels

- key escort/puzzles
    - key is bouncing back and forth
    - whip out of the air
    - throw item at it
- TNT explodes slowly over time and player dodges shrapnel (rocks)
- timed bomb throws - walls, enemies
- ropes
- climbing gloves/spring shoes/jetpack mini metroidvania
- cape level :)
- blast items across gap with TNT
- ropes that burn when you touch them
- Spend all your monry (shops - have to do math) w/ ghost
- Guide cat to enemey who has 99999 HP in order to murder
    - throw cursed pots
- jetpack that explodes after awhile
- colored keys/doors
- mattock level
- bone drop trap - ammo for pitchers mitt challenge
- timed firefrog throws
- timed frog jumps
- ride big CB up, jump out and over as another big CB comes down on you like a hydralic press

- Run from Quillback into Olmec. Use Olmec to kill Quillback. Olmec glows red and can't be stepped on
- Escape from Sunken City


DONE

- Thorny Jail
- Gugubo level (Glue & bow?) - - arrow of Light - Light or Sus Glue Bow Bow
- inverse timed doors
- ladders & sticky traps & spikeball trap & arrow traps
- death block elevator
- blocks that appear when a switch is hit for a short timer
- Spelunky Community Tile Pack
- chained ufo jumps (jump off ufo & alien)
- run under lava going down elevator
- elevator jumps, lava elevators
- timed doors
- Flying Fish
- COllect gold while ghost chases you level (Twiggle Level)
- jungle: claustrophopic climbing gloves / thorns lvl
- sorceress barrage (like fish)


# Obstacles

From @Cynichill

Stay in the air by jumping on eggy people & jetpack (DONE)

a speedrun level using the traps could be fun, for a unique timer you could use a poisoned mount

Lahamu but you use push blocks to cover and uncover those.. upward laser trap things to bounce ufos into her? (DONE kinda)

Space invaders-type UFO level - kill with forcefield (DONE)

Don't cook the turkey - mounts can ride death blocks

shooting a bubbled enemy with another bubble pushes the bubble away

Defend against fish barrage - tidepool 3

If water makes you immune to magma men, you could do something like having pools of water as safety zones the player has to reach between magma men hell. Could use rock dogs

Throw bodies at spark traps to trigger far away stuff & weird angles

vertical level about guiding the bubble to the top without popping